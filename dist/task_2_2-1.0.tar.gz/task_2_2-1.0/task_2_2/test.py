from selenium import webdriver
from selenium.webdriver.common.by import By
import time



driver = webdriver.Firefox(executable_path=r'C:\geckodriver')

driver.get("https://edube.org/add-pearsonvue-account")

driver.find_element(value="email").send_keys("klukowski_dawid@o2.pl")

time.sleep(15)

while True:
    driver.get("https://edube.org/add-pearsonvue-account")
    time.sleep(1)
    driver.find_element(by=By.ID, value="pearson_vue_add_account_clientCandidateId").send_keys("CPI057781")
    driver.find_element(value="pearson_vue_add_account_email").send_keys("klukowski_dawid@o2.pl")
    time.sleep(1)

    driver.find_element(by=By.XPATH, value="//*[@class='button btn-quiz-primary']").click()

    time.sleep(5)
